
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ferb7o2',
  applicationName: 'halsey-lyrics-api',
  appUid: 'V85R5T4YjkHFC0gDcX',
  orgUid: '48a5a4a2-14df-42bc-8f75-f4481c62cf85',
  deploymentUid: '4d6997a2-82db-43e9-9870-e32ee701fd49',
  serviceName: 'halsey-lyrics-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'halsey-lyrics-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}