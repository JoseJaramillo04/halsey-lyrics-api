
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ferb7o2',
  applicationName: 'halsey-lyrics-api',
  appUid: 'V85R5T4YjkHFC0gDcX',
  orgUid: '48a5a4a2-14df-42bc-8f75-f4481c62cf85',
  deploymentUid: '5f7375cb-2db2-49d0-bdc0-8ea059f5b962',
  serviceName: 'halsey-lyrics-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'halsey-lyrics-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}